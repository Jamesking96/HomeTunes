// Tests for editing and organising audiobooks: book details (narrator, series) stored as
// HomeTunes edits, editing a whole book in a real temp library, bookmarks (BookmarksModel),
// the Open Library book lookup (services/book_info.dart, no network), bookmarks in backups,
// searching books and chapters, and the Books tab's sort and filter options
// (state/book_index.dart). Helper book builders are at the bottom of the file.
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hometunes/models/book.dart';
import 'package:hometunes/models/track.dart';
import 'package:hometunes/models/track_edit.dart';
import 'package:hometunes/services/app_backup.dart';
import 'package:hometunes/services/book_info.dart';
import 'package:hometunes/services/storage.dart';
import 'package:hometunes/services/tag_writer.dart';
import 'package:hometunes/state/book_index.dart';
import 'package:hometunes/state/bookmarks_model.dart';
import 'package:hometunes/state/library_model.dart';
import 'package:path/path.dart' as p;

import 'metadata_features_test.dart' show silentWav;

/// A made-up book file at [path], optionally with book details already set.
Track part(String path, {int minutes = 10, int? n, String? narrator, String? series, double? seriesIndex}) => Track(
      id: 'local:$path',
      source: TrackSource.local,
      title: p.basenameWithoutExtension(path),
      artist: 'Author',
      album: 'Album',
      albumArtist: 'Author',
      trackNumber: n,
      duration: Duration(minutes: minutes),
      path: path,
      narrator: narrator,
      series: series,
      seriesIndex: seriesIndex,
    );

void main() {
  group('Book details as edits', () {
    // The book fields behave like every other edit: saved and loaded, merged, applied to a song,
    // and dropped when they match the file again.
    test('narrator and series survive JSON, merging and "back to the file"', () {
      const e = TrackEdit(narrator: 'Stephen Fry', series: 'Harry Potter', seriesIndex: 2);
      final again = TrackEdit.fromJson(e.toJson());
      expect(again.narrator, 'Stephen Fry');
      expect(again.seriesIndex, 2);
      expect(const TrackEdit(title: 'X').mergedWith(e).series, 'Harry Potter');
      final t = part(r'F:\B\1.mp3');
      expect(e.applyTo(t).narrator, 'Stephen Fry');
      expect(TrackEdit(narrator: t.narrator).normalizedAgainst(t).isEmpty, isTrue);
      expect(Track.fromJson(e.applyTo(t).toJson()).series, 'Harry Potter');
    });

    // There are no standard tags for narrator and series, so they're never written into files.
    test('they always stay in HomeTunes when writing tags into files', () {
      final left = TagSupport.forPath('a.mp3').leftover(const TrackEdit(title: 'T', narrator: 'N', series: 'S'));
      expect(left.title, isNull);
      expect(left.narrator, 'N');
      expect(left.series, 'S');
    });

    // Without edits, narrator and series number come from the folder names; edits override that,
    // and an edit of '' means "none" rather than "use the folder name".
    test('edited details win over folder names; empty clears them', () {
      const dir = r'F:\HP Audio Books 1-7; Read by Stephen Fry\Book 02 - Chamber';
      final fromFolders = groupBooks([part('$dir\\01.mp3')]).single;
      expect(fromFolders.narrator, 'Stephen Fry');
      expect(fromFolders.seriesIndex, 2);

      final edited = groupBooks([
        part('$dir\\01.mp3', narrator: 'Jim Dale', series: 'Harry Potter', seriesIndex: 2.5),
      ]).single;
      expect(edited.narrator, 'Jim Dale');
      expect(edited.series, 'Harry Potter');
      expect(edited.seriesIndex, 2.5);

      final cleared = groupBooks([part('$dir\\01.mp3', narrator: '', series: '')]).single;
      expect(cleared.narrator, isNull);
      expect(cleared.series, isNull);
    });
  });

  // A real temp library with a two-file book (tiny silent WAVs) in an audiobook folder.
  group('Editing a book in the library', () {
    late Directory dir;
    late LibraryModel lib;

    setUp(() async {
      TestWidgetsFlutterBinding.ensureInitialized();
      dir = Directory.systemTemp.createTempSync('hometunes_editbook');
      final storage = Storage.at(Directory(p.join(dir.path, 'data'))..createSync());
      Directory(storage.artDir).createSync();
      final book = Directory(p.join(dir.path, 'books', 'A Story'))..createSync(recursive: true);
      File(p.join(book.path, '01.wav')).writeAsBytesSync(silentWav());
      File(p.join(book.path, '02.wav')).writeAsBytesSync(silentWav());
      lib = LibraryModel(storage);
      await lib.addAudiobookFolder(p.join(dir.path, 'books'));
    });
    // Short wait so any save still in progress finishes before the folder is deleted.
    tearDown(() async {
      await Future<void>.delayed(const Duration(milliseconds: 100));
      dir.deleteSync(recursive: true);
    });

    // Editing a book edits all its files at once (the book's title is the files' album name).
    // Resetting the edits brings back the folder name as the title.
    test('title, author, narrator and cover apply to every file', () async {
      final b = lib.books.single;
      final ids = [for (final t in b.parts) t.id];
      final cover = await lib.importCoverBytes([0xFF, 0xD8, 0xFF, 0xE0, 9, 9]);
      await lib.editMany(
        ids,
        TrackEdit(album: 'The Real Title', artist: 'Real Author', albumArtist: 'Real Author', narrator: 'N', art: cover),
      );
      final now = lib.books.single;
      expect(now.title, 'The Real Title');
      expect(now.author, 'Real Author');
      expect(now.narrator, 'N');
      expect(now.parts.length, 2);
      expect(now.artTrack!.art, cover);
      expect(lib.bookOfTrack(ids.first)!.id, now.id); // how the page follows a renamed book
      expect(lib.searchBooks('real auth').single.id, now.id);

      await lib.resetEdits(ids);
      expect(lib.books.single.title, 'A Story');
    });
  });

  group('Bookmarks', () {
    late Directory dir;
    late BookmarksModel model;
    // Two 30-minute files; bookmarks are stored per file and position.
    final book = Book(id: 'b', title: 'B', author: 'A', parts: [
      part(r'F:\B\1.mp3', minutes: 30),
      part(r'F:\B\2.mp3', minutes: 30),
    ]);

    setUp(() async {
      dir = Directory.systemTemp.createTempSync('hometunes_bm');
      model = BookmarksModel(Storage.at(dir));
      await model.load();
    });
    tearDown(() async {
      await Future<void>.delayed(const Duration(milliseconds: 100));
      dir.deleteSync(recursive: true);
    });

    // Bookmarks come back in the order they occur in the book, not the order they were added.
    test('added, listed in listening order, noted, deleted and saved', () async {
      final late = await model.add(book.parts[1].id, const Duration(minutes: 5), note: 'Twist!');
      final early = await model.add(book.parts[0].id, const Duration(minutes: 20));
      expect([for (final b in model.forBook(book)) b.id], [early.id, late.id]);
      await model.setNote(early, 'Start of the chase');
      final again = BookmarksModel(Storage.at(dir));
      await again.load();
      final list = again.forBook(book);
      expect(list.first.note, 'Start of the chase');
      expect(list.last.position, const Duration(minutes: 5));
      await model.remove(late);
      expect(model.forBook(book).length, 1);
    });

    // When files move, their bookmarks follow the new ids; when files are dropped from the
    // library, their bookmarks go too.
    test('follow moved files; forgotten files take their bookmarks with them', () async {
      final b = await model.add(book.parts[0].id, const Duration(minutes: 1));
      model.remapIds({book.parts[0].id: 'local:G:\\B\\1.mp3'});
      expect(model.referencedIds, {'local:G:\\B\\1.mp3'});
      model.removeIds({'local:G:\\B\\1.mp3'});
      expect(model.referencedIds, isEmpty);
      expect(b.note, '');
    });
  });

  // Only the request address and reading a fake reply; results with the same work key count once.
  group('Open Library', () {
    test('search query and results', () {
      final u = BookInfoSearch.buildQuery(title: 'The Hobbit', author: 'Tolkien');
      expect(u.host, 'openlibrary.org');
      expect(u.queryParameters['title'], 'The Hobbit');
      expect(u.queryParameters['author'], 'Tolkien');
      final r = BookInfoSearch.parse({
        'docs': [
          {'key': '/works/1', 'title': 'The Hobbit', 'author_name': ['J.R.R. Tolkien'], 'first_publish_year': 1937, 'cover_i': 42},
          {'key': '/works/1', 'title': 'duplicate'},
          {'key': '/works/2', 'title': 'No cover'},
        ],
      });
      expect(r.length, 2);
      expect(r.first.author, 'J.R.R. Tolkien');
      expect(r.first.year, 1937);
      expect(r.last.coverId, isNull);
      expect(BookInfoSearch.coverUrl(42, large: true).path, '/b/id/42-L.jpg');
    });
  });

  // Take a backup with bookmark "a", replace the saved bookmarks with "b", then restore in
  // "merge" mode: both should be there (the current ones first).
  test('backups carry bookmarks, and merging keeps both sets', () async {
    final dir = Directory.systemTemp.createTempSync('hometunes_bmbackup');
    addTearDown(() => dir.deleteSync(recursive: true));
    final storage = Storage.at(dir);
    await storage.write('bookmarks.json', {
      'bookmarks': [
        {'id': 'a', 'part': 'p', 'posMs': 1, 'created': 1},
      ],
    });
    final backup = AppBackup.read(await AppBackup.create(storage));
    expect(backup.bookmarkCount, 1);
    await storage.write('bookmarks.json', {
      'bookmarks': [
        {'id': 'b', 'part': 'p', 'posMs': 2, 'created': 2},
      ],
    });
    await AppBackup.restore(storage, backup, merge: true);
    final merged = await storage.read('bookmarks.json') as Map;
    expect([for (final b in merged['bookmarks'] as List) (b as Map)['id']], ['b', 'a']);
  });

  // Three small books; the chapter titles are the file titles.
  group('Search', () {
    final books = [
      _book('The Philosopher\'s Stone', 'J.K. Rowling', ['Chapter 01 - The Boy Who Lived', 'Chapter 05 - Diagon Alley'],
          series: 'Harry Potter'),
      _book('Stone Soup', 'Someone', ['One']),
      _book('The Hobbit', 'J.R.R. Tolkien', ['An Unexpected Party']),
    ];

    test('books by title, author or series; titles starting with the search first', () {
      expect([for (final b in searchBookList(books, 'stone')) b.title], ['Stone Soup', 'The Philosopher\'s Stone']);
      expect(searchBookList(books, 'tolkien').single.title, 'The Hobbit');
      expect(searchBookList(books, 'harry potter').single.title, 'The Philosopher\'s Stone');
      expect(searchBookList(books, '  '), isEmpty);
    });

    // `chapter` is the chapter's number within its book, counting from 0.
    test('chapters by name', () {
      final hits = searchChapterList(books, 'diagon');
      expect(hits.single.book.title, 'The Philosopher\'s Stone');
      expect(hits.single.chapter, 1);
      expect(searchChapterList(books, 'boy lived').single.chapter, 0);
      expect(searchChapterList(books, 'dragon'), isEmpty);
    });
  });

  // sortBooks returns (group name, books) pairs, e.g. one group per series or author.
  group('Books tab: sort and filter', () {
    final books = [
      _b('Chamber of Secrets', author: 'J.K. Rowling', narrator: 'Stephen Fry', series: 'Harry Potter', n: 2),
      _b('Philosopher\'s Stone', author: 'J.K. Rowling', narrator: 'Stephen Fry', series: 'Harry Potter', n: 1),
      _b('Casual Vacancy', author: 'J.K. Rowling', narrator: 'Tom Hollander'),
      _b('The Hobbit', author: 'J.R.R. Tolkien', narrator: 'Andy Serkis'),
      _b('Silmarillion', author: 'J.R.R. Tolkien'),
    ];
    List<String> titles(List<Book> l) => [for (final b in l) b.title];

    test('series sort keeps the series in number order, books outside a series last', () {
      final g = sortBooks(books, BookSort.series);
      expect([for (final x in g) x.$1], ['Harry Potter', noSeries]);
      expect(titles(g.first.$2), ['Philosopher\'s Stone', 'Chamber of Secrets']);
    });

    test('author groups follow series order inside', () {
      final g = sortBooks(books, BookSort.author);
      expect([for (final x in g) x.$1], ['J.K. Rowling', 'J.R.R. Tolkien']);
      expect(titles(g.first.$2), ['Casual Vacancy', 'Philosopher\'s Stone', 'Chamber of Secrets']);
    });

    test('narrator groups, unknown narrator last', () {
      final g = sortBooks(books, BookSort.narrator);
      expect([for (final x in g) x.$1], ['Andy Serkis', 'Stephen Fry', 'Tom Hollander', noNarrator]);
      expect(titles(g[1].$2), ['Philosopher\'s Stone', 'Chamber of Secrets']);
      expect(titles(g.last.$2), ['Silmarillion']);
    });

    test('title sort is plain A–Z', () {
      expect(titles(sortBooks(books, BookSort.title).single.$2).first, 'Casual Vacancy');
    });

    // choices() lists the values offered in a filter menu, with how many books have each.
    test('filters by author, narrator and series, and lists choices with counts', () {
      const f = BookFilters(author: 'J.K. Rowling', series: 'Harry Potter');
      expect(titles([for (final b in books) if (f.matches(b)) b]), ['Chamber of Secrets', 'Philosopher\'s Stone']);
      expect(f.copyWith(clearSeries: true).series, isNull);
      expect(BookFilters.none.isEmpty, isTrue);
      expect(BookFilters.choices(books, (b) => b.narrator), {'Andy Serkis': 1, 'Stephen Fry': 2, 'Tom Hollander': 1});
    });
  });
}

// ---------------------------------------------------------------- search

/// A book whose files are named after [chapterTitles] (one file per chapter).
Book _book(String title, String author, List<String> chapterTitles, {String? series}) => Book(
      id: 'book:$title',
      title: title,
      author: author,
      series: series,
      parts: [
        for (var i = 0; i < chapterTitles.length; i++)
          Track(
            id: 'local:F:\\$title\\$i.mp3',
            source: TrackSource.local,
            title: chapterTitles[i],
            artist: author,
            album: title,
            albumArtist: author,
            duration: const Duration(minutes: 20),
            path: 'F:\\$title\\$i.mp3',
          ),
      ],
    );

/// A one-file book with the given details, for the sort and filter tests.
Book _b(String title, {String author = 'A', String? narrator, String? series, double? n, int added = 0}) => Book(
      id: 'book:$title',
      title: title,
      author: author,
      narrator: narrator,
      series: series,
      seriesIndex: n,
      parts: [
        Track(
          id: 'local:F:\\$title.mp3',
          source: TrackSource.local,
          title: title,
          artist: author,
          album: title,
          albumArtist: author,
          path: 'F:\\$title.mp3',
          modifiedMs: added,
        ),
      ],
    );
