// The user's playlists, their "Liked Songs" and their favourite albums and audiobooks, saved
// together in playlists.json.
//
// Favourite albums and books are stored as the ids of their songs/files rather than album keys
// or book ids, so they follow the same rules as playlists: they survive edits that regroup an
// album, files that move, and backups. An album or book is a favourite when any of its songs is
// in the set.
//
// Playlists store track ids only (not copies of the songs), so edits to a song show up
// everywhere. Because of that, LibraryModel keeps songs that are in a playlist even when their
// file disappears (`referencedIds`), and tells this model when files move (`remapIds`) or when
// the user forgets missing songs (`removeIds`). Every change is saved straight away.
import 'package:flutter/foundation.dart';

import '../models/book.dart';
import '../models/playlist.dart';
import '../models/track.dart';
import '../services/storage.dart';

/// User playlists plus the special "Liked Songs" list.
class PlaylistsModel extends ChangeNotifier {
  final Storage storage;
  PlaylistsModel(this.storage);

  /// The user's playlists, in the order they were made.
  List<Playlist> playlists = [];

  /// Liked track ids, most recently liked first.
  List<String> liked = [];
  // The same ids as a set, so "is this song liked?" is a quick look-up while drawing lists.
  Set<String> _likedSet = {};

  // Song/file ids of favourite albums and favourite audiobooks.
  Set<String> _favAlbums = {};
  Set<String> _favBooks = {};

  /// Reads playlists.json (at start-up and after a backup is restored).
  Future<void> load() async {
    playlists = [];
    liked = [];
    _favAlbums = {};
    _favBooks = {};
    // HomeTunes: read piece by piece, so one damaged playlist (or a wrong type anywhere) skips
    // just that piece instead of stopping the app from starting. If anything was skipped, a
    // copy of the file is kept before the next save replaces it.
    final j = await storage.read('playlists.json');
    var damaged = j != null && j is! Map;
    List<String> ids(Object? v) {
      if (v == null) return [];
      if (v is! List) {
        damaged = true;
        return [];
      }
      final out = [for (final x in v) if (x is String) x];
      if (out.length != v.length) damaged = true;
      return out;
    }

    if (j is Map) {
      final lists = j['playlists'];
      if (lists != null && lists is! List) damaged = true;
      for (final p in lists is List ? lists : const []) {
        try {
          playlists.add(Playlist.fromJson(p as Map<String, dynamic>));
        } catch (_) {
          damaged = true;
        }
      }
      liked = ids(j['liked']);
      _favAlbums = ids(j['favouriteAlbums']).toSet();
      _favBooks = ids(j['favouriteBooks']).toSet();
    }
    if (damaged) await storage.keepCopy('playlists.json');
    _likedSet = liked.toSet();
    notifyListeners();
  }

  Future<void> _save() => storage.write('playlists.json', {
        'playlists': [for (final p in playlists) p.toJson()],
        'liked': liked,
        'favouriteAlbums': _favAlbums.toList(),
        'favouriteBooks': _favBooks.toList(),
      });

  /// Redraws listeners and saves. Called after every change. The save isn't awaited: the
  /// storage service writes files one at a time, so saves can't overlap.
  void _changed() {
    notifyListeners();
    _save();
  }

  bool isLiked(Track t) => _likedSet.contains(t.id);

  /// Likes the song (putting it at the top of Liked Songs) or unlikes it.
  void toggleLike(Track t) {
    if (_likedSet.remove(t.id)) {
      liked.remove(t.id);
    } else {
      _likedSet.add(t.id);
      liked.insert(0, t.id);
    }
    _changed();
  }

  // ---- favourite albums and books ----

  bool isFavouriteAlbum(Album a) => a.tracks.any((t) => _favAlbums.contains(t.id));
  bool isFavouriteBook(Book b) => b.parts.any((t) => _favBooks.contains(t.id));

  /// Makes [albums] favourites, or not.
  void setFavouriteAlbums(Iterable<Album> albums, bool favourite) {
    for (final a in albums) {
      for (final t in a.tracks) {
        favourite ? _favAlbums.add(t.id) : _favAlbums.remove(t.id);
      }
    }
    _changed();
  }

  /// Makes [books] favourites, or not.
  void setFavouriteBooks(Iterable<Book> books, bool favourite) {
    for (final b in books) {
      for (final t in b.parts) {
        favourite ? _favBooks.add(t.id) : _favBooks.remove(t.id);
      }
    }
    _changed();
  }

  /// Makes a new empty playlist. Its id is the current time in microseconds, which is unique
  /// enough for playlists made by hand.
  Playlist create(String name) {
    final p = Playlist(id: DateTime.now().microsecondsSinceEpoch.toString(), name: name.trim());
    playlists.add(p);
    _changed();
    return p;
  }

  void rename(Playlist p, String name) {
    p.name = name.trim();
    _changed();
  }

  void delete(Playlist p) {
    playlists.remove(p);
    _changed();
  }

  /// Adds tracks, skipping ones already in the playlist. Returns how many were added.
  int addTracks(Playlist p, Iterable<Track> tracks) {
    var added = 0;
    for (final t in tracks) {
      if (!p.trackIds.contains(t.id)) {
        p.trackIds.add(t.id);
        added++;
      }
    }
    if (added > 0) _changed();
    return added;
  }

  /// Removes the song at position [index] in the playlist.
  void removeAt(Playlist p, int index) {
    p.trackIds.removeAt(index);
    _changed();
  }

  /// Replaces the order of a playlist's songs.
  void setOrder(Playlist p, List<String> ids) {
    p.trackIds
      ..clear()
      ..addAll(ids);
    _changed();
  }

  /// Every track id used by a playlist, Liked Songs or a favourite album or book.
  Set<String> get referencedIds =>
      {..._likedSet, ..._favAlbums, ..._favBooks, for (final p in playlists) ...p.trackIds};

  /// Songs that moved (old id → new id) keep their places in playlists and likes.
  void remapIds(Map<String, String> moved) {
    if (moved.isEmpty) return;
    var changed = false;
    // Swaps old ids for new ones, keeping the order. If a moved song's new id is already in the
    // list (say the file was copied rather than moved), the duplicate is dropped.
    List<String> remap(List<String> ids) {
      final out = <String>[];
      final seen = <String>{};
      for (final id in ids) {
        final n = moved[id] ?? id;
        if (n != id) changed = true;
        if (seen.add(n)) out.add(n);
      }
      return out;
    }

    for (final p in playlists) {
      final ids = remap(p.trackIds);
      p.trackIds
        ..clear()
        ..addAll(ids);
    }
    liked = remap(liked);
    _likedSet = liked.toSet();
    _favAlbums = remap(_favAlbums.toList()).toSet();
    _favBooks = remap(_favBooks.toList()).toSet();
    if (changed) _changed();
  }

  /// Removes songs from every playlist and from Liked Songs.
  void removeIds(Set<String> ids) {
    if (ids.isEmpty) return;
    for (final p in playlists) {
      p.trackIds.removeWhere(ids.contains);
    }
    liked.removeWhere(ids.contains);
    _likedSet = liked.toSet();
    _favAlbums.removeAll(ids);
    _favBooks.removeAll(ids);
    _changed();
  }

  /// Finds a playlist by its id, or null if it has been deleted.
  Playlist? byId(String id) {
    for (final p in playlists) {
      if (p.id == id) return p;
    }
    return null;
  }
}
