## 0.0.3
* Local cover art support by @GerryDush
* Crash fixed by @AfalpHy - Null data handling

## 0.0.2

* Bug resolved for blank notification at start.
* Log cleanup.

## 0.0.1

* Initial release 🎉
* Windows platform implementation for `audio_service`.
* System Media Transport Controls (SMTC) integration.
* Media metadata (title, artist, album, artwork) display.
* Media button events (play, pause, next, previous, etc.).
* Compatible with `audio_service_platform_interface`.
